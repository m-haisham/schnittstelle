
def delete_line():
    print('\033[2K\033[1G', end='')